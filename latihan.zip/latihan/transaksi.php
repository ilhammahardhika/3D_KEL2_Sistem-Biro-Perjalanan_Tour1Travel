<?php
//panggil file koneksi.php yang sudah anda buat
include "koneksi.php";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>JUDUL WEBSITE ANDA</title>
</head>
<body>
<h1 align="center"> Data Transaksi</h1>
    <table border="1" width="600px" align="center">
       <thead>
       <tr>
           <th>no trans</th>
           <th>tanggal trans</th>
           <th>sub total</th>
           <th>total chars</th>
           <th>total</th>
       </tr>
       </thead>

       <tbody>
<?php
//ambil data dari tb_admin di database
$ambildata=mysqli_query($conect, "SELECT * FROM transaksi order by no_trans desc");
while($a=mysqli_fetch_array($ambildata)){
    ?>
       <tr>
           <td><?php echo $a['no_trans'];?></td>
           <td><?php echo $a['tgl_trans'];?></td>
           <td><?php echo $a['sub_total'];?></td>
           <td><?php echo $a['total_chars'];?></td>
           <td><?php echo $a['total'];?></td>
       </tr>
<?php
}
?>
</tbody>

</table>

</body>
</html>