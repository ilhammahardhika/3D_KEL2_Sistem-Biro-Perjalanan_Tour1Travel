<?php
//panggil file koneksi.php yang sudah anda buat
include "koneksi.php";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>JUDUL WEBSITE ANDA</title>
</head>
<body>
<h1 align="center"> Data Detail</h1>
    <table border="1" width="600px" align="center">
       <thead>
       <tr>
           <th>no trans</th>
           <th>kode paket</th>   
           <th>tujuan wisata</th>
           <th>tanggal pesan</th>
           <th>tanggal berangkat</th>
           <th>transportasi</th>
           <th>penginapan</th>
           <th>restoran</th>
       </tr>
       </thead>

       <tbody>
<?php
//ambil data dari tb_admin di database
$ambildata=mysqli_query($conect, "SELECT * FROM detail order by no_trans desc");
while($a=mysqli_fetch_array($ambildata)){
    ?>
       <tr>
           <td><?php echo $a['no_trans'];?></td>
           <td><?php echo $a['kode_paket'];?></td>
           <td><?php echo $a['tujuan_wisata'];?></td>
           <td><?php echo $a['tanggal_pesan'];?></td>
           <td><?php echo $a['tgl_berangkat'];?></td>
           <td><?php echo $a['transportasi'];?></td>
           <td><?php echo $a['penginapan'];?></td>
           <td><?php echo $a['restoran'];?></td>
       </tr>
<?php
}
?>
</tbody>

</table>

</body>
</html>