<?php
//panggil file koneksi.php yang sudah anda buat
include "koneksi.php";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>JUDUL WEBSITE ANDA</title>
</head>
<body>
<h1 align="center"> Data Paket</h1>
    <table border="1" width="600px" align="center">
       <thead>
       <tr>
           <th>Nama paket</th>
           <th>Tujuan</th>
           <th>Jam Berangkat</th>
           <th>Jam tiba</th>
           <th>Harga</th>
       </tr>
       </thead>

       <tbody>
<?php
//ambil data dari tb_admin di database
$ambildata=mysqli_query($conect, "SELECT * FROM paket order by kode_paket desc");
while($a=mysqli_fetch_array($ambildata)){
    ?>
       <tr>
           <td><?php echo $a['nama_paket'];?></td>
           <td><?php echo $a['tujuan'];?></td>
           <td><?php echo $a['jam_berangkat'];?></td>
           <td><?php echo $a['jam_tiba'];?></td>
           <td><?php echo $a['harga'];?></td>
       </tr>
<?php
}
?>
</tbody>

</table>

</body>
</html>