<?php
//panggil file koneksi.php yang sudah anda buat
include "koneksi.php";
?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>JUDUL WEBSITE ANDA</title>
</head>
<body>
<h1 align="center"> Data Costumer</h1>
    <table border="1" width="600px" align="center">
       <thead>
       <tr>
           <th>Nama Costumer</th>
           <th>Alamat</th>
           <th>No Telpon</th>
       </tr>
       </thead>

       <tbody>
<?php
//ambil data dari tb_admin di database
$ambildata=mysqli_query($conect, "SELECT * FROM Costumer order by kode_costumer desc");
while($a=mysqli_fetch_array($ambildata)){
    ?>
       <tr>
           <td><?php echo $a['nama_costumer'];?></td>
           <td><?php echo $a['alamat'];?></td>
           <td><?php echo $a['notelp'];?></td>
       </tr>
<?php
}
?>
</tbody>

</table>

</body>
</html>